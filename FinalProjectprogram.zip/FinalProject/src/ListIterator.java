
public class ListIterator {
	private Link current;
	private Link previous;
	private LinkList ourList;

	public ListIterator(LinkList list) {
		ourList = list;
		reset();
	}

	public void reset() {
		current = ourList.getFirst();
		previous = null;
	}

	public boolean atEnd() {
		return (current.next == null);
	}

	public void nextLink() {
		previous = current;
		current = current.next;
	}

	public String getCurrent() {
		String input = current.displayLink();
		current = current.next;
		return input;
	}

	public void insertAfter(String fN, String lN, String pN, String email, String address, String state, String zip,
			String licensePlate) {
		Link newLink = new Link(fN, lN, pN, email, address, state, zip, licensePlate);

		if (ourList.isEmpty()) {
			ourList.setFirst(newLink);
			current = newLink;
		} else {
			newLink.next = current.next;
			current.next = newLink;
			nextLink();
		}
	}

	public void insertBefore(String fN, String lN, String pN, String email, String address, String state, String zip,
			String licensePlate) {
		Link newLink = new Link(fN, lN, pN, email, address, state, zip, licensePlate);
		if (previous == null) {
			newLink.next = ourList.getFirst();
			ourList.setFirst(newLink);
			reset();
		} else {
			newLink.next = previous.next;
			previous.next = newLink;
			current = newLink;
		}
	}
}
