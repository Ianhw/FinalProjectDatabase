

public class Queue {

	private int maxSize;
	private String[] queArray;
	private int front;
	private int rear;
	private int nItems;
	public String FN,LN,PN,Email,Addres,State,Zip,LicensePlate;

	public Queue(String fN, String lN, String pN, String email, String address, String state, String zip,
			String licensePlate) {

		maxSize = 100;
		
		queArray = new String[maxSize];
		front = 0;
		rear = -1;
		nItems = 0;
		FN = fN;
		LN = lN;
		PN = pN;
		Email = email;
		Addres = address;
		State = state;
		Zip = zip;
		LicensePlate = licensePlate;
		
	}

	public void insert(String FN, String LN, String PN, String Email, String Addres, String State, String Zip,
			String LicensePlate) {
		String input = "{" + "First Name: "+ FN + ", " +"  Last Name: "+ LN +", "+"   Phone Number: "+ PN + ", " +"  Email: "+ Email +", " +"  Address: "+ Addres + ", " +"  State: "+  State +", "+"  Zip: "+  Zip + ", " +"  LicensePlate: "+ LicensePlate + "}";
		if (rear == maxSize - 1)
			rear = -1;
		queArray[++rear] = input;
		nItems++;
		}

	public String remove() {
		String temp = queArray[front++];
		if (front == maxSize)
			front = 0;
		nItems--;
		return temp;
	}

	public String peekFront() {
		
		return queArray[front++];
	}

	public String peek() {
		//System.out.println("outputing");
		return queArray[front];
	}
	
	public boolean isEmpty() {
		return (nItems == 0);
	}

	public boolean isFull() {
		return (nItems == maxSize);
	}

	public int Size() {
		return nItems;
	}
	public void printarray() {
		for(String s : queArray) { 
			System.out.println(queArray.toString()); 
			}
	}
	public String toString(String fN, String lN, String pN, String email, String address, String state, String zip,
			String licensePlate) {
		
		return "[FN=" + fN + ", LN=" + lN + ", PN=" + pN + ", Email=" + email + ", Addres=" + address + ", State="
				+ state + ", Zip=" + zip + ", LicensePlate=" + licensePlate + "]";
	}

	
	
}
