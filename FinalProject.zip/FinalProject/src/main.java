
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import javax.swing.JCheckBox;

public class main {
	main() {
		JFrame f = new JFrame("Heartland Storage Reservation Request");

		// submit button
		JButton SubmitButtton = new JButton("Submit");
		SubmitButtton.setBounds(20, 460, 140, 40);
		f.add(SubmitButtton);
		JButton Clear = new JButton("Clear");
		Clear.setBounds(170, 460, 140, 40);
		f.add(Clear);

		// First name
		JLabel FN = new JLabel();
		FN.setText("First Name:");
		FN.setBounds(10, 10, 100, 100);

		JTextField FNText = new JTextField();
		FNText.setBounds(110, 50, 130, 30);

		f.add(FNText);
		f.add(FN);
		// end first name

		// Last name
		JLabel LN = new JLabel();
		LN.setText("Last name:");
		LN.setBounds(10, 60, 100, 100);

		JTextField LNText = new JTextField();
		LNText.setBounds(110, 95, 130, 30);

		f.add(LNText);
		f.add(LN);
		// end Last name

		// Phone Number
		JLabel PN = new JLabel();
		PN.setText("Phone Number:");
		PN.setBounds(10, 110, 100, 100);

		JTextField PNText = new JTextField();
		PNText.setBounds(110, 145, 130, 30);

		f.add(PNText);
		f.add(PN);
		// end Phone number

		// Email
		JLabel Email = new JLabel();
		Email.setText("Email:");
		Email.setBounds(10, 160, 100, 100);

		JTextField EmailText = new JTextField();
		EmailText.setBounds(110, 195, 130, 30);

		f.add(EmailText);
		f.add(Email);
		// end Email

		// Address
		JLabel Address = new JLabel();
		Address.setText("Address:");
		Address.setBounds(10, 210, 100, 100);

		JTextField AddressText = new JTextField();
		AddressText.setBounds(110, 245, 130, 30);

		f.add(AddressText);
		f.add(Address);
		// end Address

		// State
		JLabel State = new JLabel();
		State.setText("State:");
		State.setBounds(10, 260, 100, 100);

		JTextField StateText = new JTextField();
		StateText.setBounds(110, 295, 130, 30);

		f.add(StateText);
		f.add(State);
		// end State

		// Zip
		JLabel Zip = new JLabel();
		Zip.setText("Zip:");
		Zip.setBounds(10, 310, 100, 100);

		JTextField ZipText = new JTextField();
		ZipText.setBounds(110, 345, 130, 30);

		f.add(ZipText);
		f.add(Zip);
		// end Zip

		// license plate
		JLabel Licenseplate = new JLabel();
		Licenseplate.setText("License Plate:");
		Licenseplate.setBounds(10, 360, 100, 100);

		JTextField LicenseplateText = new JTextField();
		LicenseplateText.setBounds(110, 395, 130, 30);

		f.add(LicenseplateText);
		f.add(Licenseplate);
		// end License plate

		/*
		 * Storing type check box JLabel CheckBoxLabel = new JLabel();
		 * CheckBoxLabel.setText("Please Click what you are wanting to store.");
		 * CheckBoxLabel.setBounds(300, 10, 250, 100); JCheckBox StorageUnit = new
		 * JCheckBox("Storage Unit"); StorageUnit.setBounds(300, 80, 250, 25); JCheckBox
		 * OutSideCamper = new JCheckBox("Out Side Camper,Boat,Rv,Car");
		 * OutSideCamper.setBounds(300, 100, 250, 25); JCheckBox InsideSideCamper = new
		 * JCheckBox("Inside Side Camper,Boat,Rv,Car"); InsideSideCamper.setBounds(300,
		 * 120, 250, 25);
		 * 
		 * f.add(StorageUnit); f.add(OutSideCamper); f.add(InsideSideCamper);
		 * f.add(CheckBoxLabel);
		 */ // end Storing type check box

		// Storing Size check box
		JLabel StorageSize = new JLabel();
		StorageSize.setText("If Camper unit please select what size");
		StorageSize.setBounds(300, 65, 400, 25);
		JLabel StorageSize2 = new JLabel();
		StorageSize2.setText("your wanting to store. In length.");
		StorageSize2.setBounds(300, 80, 400, 25);
		JCheckBox Small = new JCheckBox("Less than 35 feet including hitch");
		Small.setBounds(300, 100, 300, 25);
		JCheckBox medium = new JCheckBox("Between 36 feet and 45 including hitch");
		medium.setBounds(300, 120, 300, 25);
		JCheckBox large = new JCheckBox("Larger than 45 feet including hitch");
		large.setBounds(300, 140, 300, 25);

		f.add(Small);
		f.add(medium);
		f.add(large);
		f.add(StorageSize);
		f.add(StorageSize2);
		// end Storing type check box

		// Storing unit Size check box
		JLabel StorageunitSize = new JLabel();
		StorageunitSize.setText("If Storage unit please select what size");
		StorageunitSize.setBounds(300, 200, 400, 25);
		JLabel StorageunitSize2 = new JLabel();
		StorageunitSize2.setText("your wanting to store. In length.");
		StorageunitSize2.setBounds(300, 220, 400, 25);
		JCheckBox five12 = new JCheckBox("5 x 12 storage unit");
		five12.setBounds(300, 240, 300, 25);
		JCheckBox ten15 = new JCheckBox("10 x 15 storage unit");
		ten15.setBounds(300, 260, 300, 25);
		JCheckBox ten20 = new JCheckBox("10 x 20 storage unit");
		ten20.setBounds(300, 280, 300, 25);

		f.add(five12);
		f.add(ten15);
		f.add(ten20);
		f.add(StorageunitSize);
		f.add(StorageunitSize2);
		// end unit Storing type check box

		JLabel FinishOutPutLabel = new JLabel();
		FinishOutPutLabel.setBounds(20, 505, 780, 40);
		f.add(FinishOutPutLabel);

		JLabel linkoutput = new JLabel();
		linkoutput.setBounds(20, 590, 780, 40);
		f.add(linkoutput);
		// add to frame

		JButton Lookat = new JButton("Look at top");
		Lookat.setBounds(320, 460, 140, 40);
		f.add(Lookat);

		JButton remove = new JButton("Remove");
		remove.setBounds(470, 460, 140, 40);
		f.add(remove);
		
		JButton linkedoutput = new JButton("Look through all reservations");
		linkedoutput.setBounds(20, 550, 200, 40);
		f.add(linkedoutput);

		JButton linkednext = new JButton("Next");
		linkednext.setBounds(230, 550, 200, 40);
		//f.add(linkednext);
		
		

		JButton top = new JButton("exit");
		top.setBounds(100, 700, 140, 40);
		f.add(top);

		// output label and buttons end

		f.pack();
		f.setSize(800, 800);
		f.setLayout(null);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Queue CamperSmall = new Queue(null, null, null, null, null, null, null, null);
		Queue Campermedium = new Queue(null, null, null, null, null, null, null, null);
		Queue Camperlarge = new Queue(null, null, null, null, null, null, null, null);
		Queue StorageSmall = new Queue(null, null, null, null, null, null, null, null);
		Queue Storagemedium = new Queue(null, null, null, null, null, null, null, null);
		Queue Storagelarge = new Queue(null, null, null, null, null, null, null, null);
		LinkList ReservationList = new LinkList();
		ListIterator iter1 = ReservationList.getIterator();
		// action listener
		SubmitButtton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// taking in information from the text boxes
				String FNinput = FNText.getText();
				String LNTextinput = LNText.getText();
				String PNTextinput = PNText.getText();
				String Emailinput = EmailText.getText();
				String Addressinput = AddressText.getText();
				String StateTextinput = StateText.getText();
				String ZipTextinput = ZipText.getText();
				String LicenseplateTextinput = LicenseplateText.getText();
				// finish taking in information from the text boxes

				// creates main database in link list
			

				// inputs information to link list
				iter1.insertAfter(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
						ZipTextinput, LicenseplateTextinput);
				// ReservationList.displayList();

				if (Small.isSelected() == true) {
					CamperSmall.insert(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
							ZipTextinput, LicenseplateTextinput);
					//System.out.println(CamperSmall.peekFront());
				}
				if (medium.isSelected() == true) {
					Campermedium.insert(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
							ZipTextinput, LicenseplateTextinput);
					// System.out.println(Campermedium.peekFront());
				}
				if (large.isSelected() == true) {
					Camperlarge.insert(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
							ZipTextinput, LicenseplateTextinput);
					// System.out.println(Camperlarge.peekFront());
				}
				if (five12.isSelected() == true) {
					StorageSmall.insert(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
							ZipTextinput, LicenseplateTextinput);
					// System.out.println(StorageSmall.peekFront());
				}
				if (ten15.isSelected() == true) {
					Storagemedium.insert(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
							ZipTextinput, LicenseplateTextinput);
					// System.out.println(Storagemedium.peekFront());
				}
				if (ten20.isSelected() == true) {
					Storagelarge.insert(FNinput, LNTextinput, PNTextinput, Emailinput, Addressinput, StateTextinput,
							ZipTextinput, LicenseplateTextinput);
					//System.out.println(Storagelarge.peekFront());
				}
				FinishOutPutLabel.setText("Information has been submitted");
			}

		});
		Clear.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				FNText.setText("");
				LNText.setText("");
				PNText.setText("");
				EmailText.setText("");
				AddressText.setText("");
				StateText.setText("");
				ZipText.setText("");
				LicenseplateText.setText("");
				FinishOutPutLabel.setText("");
			}

		});
		Lookat.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// System.out.println("small");
				if (Small.isSelected() == true) {

					String output = (CamperSmall.peek());
					FinishOutPutLabel.setText(output);

				}
				if (medium.isSelected() == true) {
					String output = (Campermedium.peek());

					FinishOutPutLabel.setText(output);
				}
				if (large.isSelected() == true) {
					String output = (Camperlarge.peek());

					FinishOutPutLabel.setText(output);
				}
				if (five12.isSelected() == true) {

					String output = (StorageSmall.peek());
					FinishOutPutLabel.setText(output);
					// System.out.println(StorageSmall.toString());
				}
				if (ten15.isSelected() == true) {
					String output = (Storagemedium.peek());

					FinishOutPutLabel.setText(output);
				}
				if (ten20.isSelected() == true) {
					String output = (Storagelarge.peek());

					FinishOutPutLabel.setText(output);
				}
				

			}

		});
		remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				if (Small.isSelected() == true) {
					CamperSmall.remove();
					//System.out.println(CamperSmall.peekFront());
				}
				if (medium.isSelected() == true) {

					Campermedium.remove();
					// System.out.println(Campermedium.peekFront());
				}
				if (large.isSelected() == true) {

					Camperlarge.remove();
					// System.out.println(Camperlarge.peekFront());
				}
				if (five12.isSelected() == true) {

					StorageSmall.remove();
					// System.out.println(StorageSmall.peekFront());
				}
				if (ten15.isSelected() == true) {

					Storagemedium.remove();
					// System.out.println(Storagemedium.peekFront());
				}
				if (ten20.isSelected() == true) {

					Storagelarge.remove();
					// System.out.println(Storagelarge.peekFront());
				}

			}

		});
		top.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				 System.exit(0);
				if (Small.isSelected() == true) {

					System.out.println(CamperSmall.Size());
				}
				if (medium.isSelected() == true) {

					System.out.println(Campermedium.Size());
					// System.out.println(Campermedium.peekFront());
				}
				if (large.isSelected() == true) {

					System.out.println(Camperlarge.Size());
					// System.out.println(Camperlarge.peekFront());
				}
				if (five12.isSelected() == true) {

					System.out.println(StorageSmall.Size());
					// System.out.println(StorageSmall.peekFront());
				}
				if (ten15.isSelected() == true) {

					System.out.println(Storagemedium.Size());
					// System.out.println(Storagemedium.peekFront());
				}
				if (ten20.isSelected() == true) {

					System.out.println(Storagelarge.Size());
					// System.out.println(Storagelarge.peekFront());
				}

			}

		});
		linkedoutput.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				linkoutput.setText(iter1.getCurrent());
				ReservationList.displayList();
			}

		});
		linkednext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				iter1.nextLink();
				

			}

		});
	}

	public static void main(String[] args) {
		new main();
	}
}