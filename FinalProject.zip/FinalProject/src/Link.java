
public class Link {
	public String FN,LN,PN,Email,Addres,State,Zip,LicensePlate;
	public Link next;

	public Link(String fN, String lN, String pN, String email, String address, String state, String zip,
			String licensePlate) {
		super();
		FN = fN;
		LN = lN;
		PN = pN;
		Email = email;
		Addres = address;
		State = state;
		Zip = zip;
		LicensePlate = licensePlate;
	}

	public String displayLink() {
		String input = ("{" + "First Name: "+ FN + ", " +"  Last Name: "+ LN +", "+"   Phone Number: "+ PN + ", " +"  Email: "+ Email +", " +"  Address: "+ Addres + ", " +"  State: "+  State +", "+"  Zip: "+  Zip + ", " +"  LicensePlate: "+ LicensePlate + "}");
		return input;
	}
	
	
	
}

